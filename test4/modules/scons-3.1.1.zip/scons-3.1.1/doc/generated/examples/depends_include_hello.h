
#define string    "world"
      
