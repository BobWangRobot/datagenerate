from SConsRevision import SCons_revision
from Utilities import is_windows, whereis, platform, deb_date
from zip_utils import unzipit, zipit, zcat
from soe_utils import soelim, soscan, soelimbuilder