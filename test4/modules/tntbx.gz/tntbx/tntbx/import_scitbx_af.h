#ifndef TNTBX_IMPORT_SCITBX_AF_H
#define TNTBX_IMPORT_SCITBX_AF_H

namespace scitbx { namespace af {
}}

namespace tntbx {
  namespace af = scitbx::af;
}

#endif // TNTBX_IMPORT_SCITBX_AF_H
