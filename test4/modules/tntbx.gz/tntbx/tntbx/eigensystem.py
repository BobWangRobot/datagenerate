import boost.python
ext = boost.python.import_ext("tntbx_eigensystem_ext")
from tntbx_eigensystem_ext import *
