/* Clipper header file */
/* (C) 2000-2002 Kevin Cowtan */

#ifndef CLIPPER_MTZ_H
#define CLIPPER_MTZ_H

#include "clipper/mtz/mtz_io.h"
#include "clipper/mtz/map_io.h"

#endif
