/* Clipper header file */
/* (C) 2000-2002 Kevin Cowtan */

#ifndef CLIPPER_PHS_H
#define CLIPPER_PHS_H

#include "clipper/phs/phs_io.h"

#endif
